READ ME:
*********

This software is developed and copyrighted by HIOX Softwares.
This is given under The GNU General Public License (GPL).
This version is Dice simulator 1.0


Features:
---------
a) To start this online Dice simulator or Dice roll game, select the number of
dice to throw.
b) Press 'throw dice' button to throw the dice.
c) As a result 6 possible dice faces randomly appear in a simulation of
throwing a single or multiple dice.
d) Download the free JavaScript code and use it.


Downloads:
-----------
Please visit our site http://www.hscripts.com and do the download


Installation:
--------------
Please take 5 minutes time and read installation instructions carefully and
completely! This will ensure a proper and easy installation. 

a) Unzip the hthrow-dice.zip to extract the files throw-dice.js, images folder
and README.txt.
b) To use this Dice simulator java script, you have to include JavaScript file
into your page as,
	<script language=javascript src="hthrow-dice/throw-dice.js"></script>
c) Images used in this Dice simulator script can be changed as you wish by
giving correct image source in hthrow-dice/throw-dice.js file.


Releases:
----------
Release Date Dice simulator 1.0: 07-04-2008.

On any suggestions mail to us at support@hscripts.com

Visit us at http://www.hscripts.com
Visit us at http://www.hioxindia.com
